import React from 'react';
import { EraId } from '../types';
import { ERAS, ERA_ORDER } from '../data/evolutionData';
import { formatNumber } from '../utils/format';
import { Globe, Sparkles, Orbit, Lock, Zap } from 'lucide-react';

interface PlanetTimelineProps {
  currentEra: EraId;
  unlockedEras: EraId[];
  totalEntropy: number;
  onSelectEra: (era: EraId) => void;
}

export const PlanetTimeline: React.FC<PlanetTimelineProps> = ({
  currentEra,
  unlockedEras,
  totalEntropy,
  onSelectEra,
}) => {
  const currentIndex = ERA_ORDER.indexOf(currentEra);
  const nextEraId = ERA_ORDER[currentIndex + 1];
  const nextEra = nextEraId ? ERAS[nextEraId] : null;

  // Calculate progress toward next era
  let progressPercent = 100;
  if (nextEra) {
    const prevThreshold = ERAS[currentEra].requiredEntropy;
    const nextThreshold = nextEra.requiredEntropy;
    const earnedSincePrev = Math.max(0, totalEntropy - prevThreshold);
    const range = Math.max(1, nextThreshold - prevThreshold);
    progressPercent = Math.min(100, Math.max(0, (earnedSincePrev / range) * 100));
  }

  const currentEraInfo = ERAS[currentEra];

  return (
    <div className="w-full bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 md:p-4 backdrop-blur-xl shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono">
            Planetary Epoch:
          </span>
          <span
            className="text-xs md:text-sm font-extrabold font-display"
            style={{ color: currentEraInfo.color }}
          >
            {currentEraInfo.name}
          </span>
          <span 
            className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border"
            style={{ 
              color: currentEraInfo.color, 
              borderColor: currentEraInfo.color + '55', 
              backgroundColor: currentEraInfo.color + '15' 
            }}
          >
            {currentEraInfo.eraMultiplier}x Global Speed
          </span>
        </div>

        {nextEra ? (
          <div className="text-xs text-slate-400 font-mono flex items-center gap-2">
            <span>Next: <strong className="text-slate-200">{nextEra.name}</strong></span>
            <span className="text-emerald-400 font-bold">
              (+{formatNumber(nextEra.instantRewardEntropy)} S &amp; {nextEra.eraMultiplier}x boost)
            </span>
            <span className="text-slate-500">
              ({formatNumber(totalEntropy)} / {formatNumber(nextEra.requiredEntropy)} S)
            </span>
          </div>
        ) : (
          <div className="text-xs text-purple-400 font-mono flex items-center gap-1.5 font-bold">
            <Orbit className="w-3.5 h-3.5 animate-spin" />
            <span>Highest Position: The Breaking of AGI</span>
          </div>
        )}
      </div>

      {/* Progress Bar with glowing pulse */}
      {nextEra && (
        <div className="relative w-full h-2 rounded-full bg-slate-950 overflow-hidden mb-3 border border-slate-800">
          <div
            className="h-full transition-all duration-300 rounded-full relative"
            style={{
              width: `${progressPercent}%`,
              backgroundColor: currentEraInfo.color,
              boxShadow: `0 0 10px ${currentEraInfo.color}`,
            }}
          />
        </div>
      )}

      {/* Timeline Steps / Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {ERA_ORDER.map((eraId) => {
          const info = ERAS[eraId];
          const isUnlocked = unlockedEras.includes(eraId);
          const isCurrent = currentEra === eraId;
          const isAgi = eraId === 'agi_breaking';

          return (
            <button
              key={eraId}
              onClick={() => isUnlocked && onSelectEra(eraId)}
              disabled={!isUnlocked}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs whitespace-nowrap transition-all duration-200 ${
                isCurrent
                  ? 'bg-slate-800 text-white font-bold border shadow-md'
                  : isUnlocked
                  ? 'bg-slate-950/60 text-slate-300 hover:bg-slate-800/80 border border-slate-800'
                  : 'bg-slate-950/30 text-slate-600 border border-slate-900 cursor-not-allowed'
              }`}
              style={{
                borderColor: isCurrent ? info.color : undefined,
                boxShadow: isCurrent ? `0 0 12px ${info.glowColor}` : undefined,
              }}
            >
              {isAgi ? (
                <Orbit className={`w-3.5 h-3.5 ${isCurrent ? 'animate-spin text-purple-400' : ''}`} />
              ) : isUnlocked ? (
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: info.color }}
                />
              ) : (
                <Lock className="w-3 h-3 text-slate-600" />
              )}
              <span>{info.name}</span>
              {isUnlocked && (
                <span className="text-[10px] font-mono text-slate-400 font-normal">
                  {info.eraMultiplier}x
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
