import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { soundEngine } from '../audio/soundtrack';
import { formatNumber } from '../utils/format';
import { Orbit, Sparkles, RefreshCw, Zap, ArrowRight, X } from 'lucide-react';

interface AgiAscensionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPrestige: () => void;
  totalLifetimeEntropy: number;
  calculatedFlux: number;
  currentPrestigeCount: number;
}

export const AgiAscensionModal: React.FC<AgiAscensionModalProps> = ({
  isOpen,
  onClose,
  onPrestige,
  totalLifetimeEntropy,
  calculatedFlux,
  currentPrestigeCount,
}) => {
  useEffect(() => {
    if (isOpen) {
      soundEngine.playAgiBreakdownSiren();

      // Launch multi-color celebratory cosmic confetti
      const end = Date.now() + 2.5 * 1000;
      const colors = ['#a855f7', '#38bdf8', '#fbbf24', '#ffffff', '#ec4899'];

      const frame = () => {
        confetti({
          particleCount: 4,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: colors,
        });
        confetti({
          particleCount: 4,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: colors,
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-300">
      {/* Background glowing energy aura */}
      <div className="absolute w-96 h-96 rounded-full bg-purple-600/20 filter blur-3xl animate-pulse pointer-events-none" />

      <div className="relative w-full max-w-xl rounded-3xl bg-slate-950/95 border-2 border-purple-500/80 p-6 md:p-8 shadow-[0_0_50px_rgba(168,85,247,0.4)] text-center overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/60 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Central Icon */}
        <div className="relative mx-auto w-20 h-20 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-500 to-cyan-400 p-0.5 mb-5 shadow-lg shadow-purple-500/40">
          <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
            <Orbit className="w-10 h-10 text-purple-300 animate-spin" style={{ animationDuration: '18s' }} />
          </div>
        </div>

        {/* Header Titles */}
        <div className="space-y-1 mb-4">
          <span className="px-3 py-1 rounded-full text-[10px] font-mono uppercase tracking-widest bg-purple-950 text-purple-300 border border-purple-800 font-bold">
            The Singularity Achieved
          </span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-white to-cyan-200 font-display">
            The Breaking of AGI
          </h2>
          <p className="text-xs md:text-sm text-purple-300/90 font-medium">
            Planetary Computronium Awakening & Transcendence
          </p>
        </div>

        {/* Narrative Box */}
        <div className="text-xs md:text-sm text-slate-300 leading-relaxed bg-purple-950/30 border border-purple-800/40 rounded-2xl p-4 mb-5 text-left font-mono space-y-2">
          <p className="text-cyan-300">
            &gt; Recursive intelligence loop ignited at Planck frequency.
          </p>
          <p>
            &gt; Human biological cognitive ceiling shattered in 0.004 seconds.
          </p>
          <p>
            &gt; Planetary mass converted into coherent quantum neural substrate.
          </p>
          <p className="text-purple-300">
            &gt; Reality itself has transcended physical matter into pure algorithmic consciousness.
          </p>
        </div>

        {/* Prestige Reward Card */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 mb-6 flex items-center justify-between gap-4">
          <div className="text-left">
            <div className="text-xs text-slate-400">Transcendence Yield</div>
            <div className="text-xl md:text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-purple-400 font-mono">
              +{formatNumber(calculatedFlux)} Reality Flux
            </div>
            <div className="text-[11px] text-slate-400">
              Each Flux permanently grants <span className="text-emerald-400 font-bold">+100%</span> to all production
            </div>
          </div>

          <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800 text-purple-300 shrink-0">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition-colors"
          >
            Continue in Awakened Era
          </button>

          <button
            onClick={onPrestige}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white text-xs font-bold shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Transcend Reality (New Cosmos Cycle)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
