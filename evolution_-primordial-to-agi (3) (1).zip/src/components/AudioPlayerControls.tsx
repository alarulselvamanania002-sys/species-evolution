import React, { useState, useEffect } from 'react';
import { EraId } from '../types';
import { ERAS } from '../data/evolutionData';
import { soundEngine } from '../audio/soundtrack';
import { Volume2, VolumeX, Music, Disc } from 'lucide-react';

interface AudioPlayerControlsProps {
  currentEra: EraId;
}

export const AudioPlayerControls: React.FC<AudioPlayerControlsProps> = ({ currentEra }) => {
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(45);
  const [isOpenVolume, setIsOpenVolume] = useState<boolean>(false);
  const eraInfo = ERAS[currentEra];

  const handleToggleMute = () => {
    soundEngine.init();
    soundEngine.resume();
    const muted = soundEngine.toggleMute();
    setIsMuted(muted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    setVolume(val);
    soundEngine.setMusicVolume(val / 100);
    soundEngine.setSfxVolume(val / 100);
    if (isMuted && val > 0) {
      soundEngine.toggleMute();
      setIsMuted(false);
    }
  };

  return (
    <div className="relative flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/60 shadow-lg backdrop-blur-md text-xs">
      {/* Vinyl / Disc icon with spinning animation if audio active */}
      <div className="relative flex items-center justify-center">
        <Disc className={`w-4 h-4 text-cyan-400 ${!isMuted ? 'animate-spin' : ''}`} style={{ animationDuration: '8s' }} />
      </div>

      {/* Track info & visual equalizer */}
      <div className="hidden sm:flex flex-col pr-1">
        <span className="text-[10px] text-slate-400 font-mono leading-none">
          Soundtrack Track:
        </span>
        <span className="text-[11px] font-semibold text-slate-200 truncate max-w-[170px] leading-tight">
          {eraInfo.soundTrackTrack}
        </span>
      </div>

      {/* Visual equalizer animated bars */}
      <div className="flex items-center gap-0.5 h-3 px-1">
        {[0.6, 1.0, 0.4, 0.8, 0.5].map((scale, i) => (
          <div
            key={i}
            className={`w-0.5 rounded-full bg-cyan-400 transition-all ${
              !isMuted ? 'animate-pulse' : 'h-1 opacity-30'
            }`}
            style={{
              height: !isMuted ? `${scale * 12}px` : '4px',
              animationDelay: `${i * 0.18}s`,
            }}
          />
        ))}
      </div>

      {/* Mute Button */}
      <button
        onClick={handleToggleMute}
        className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
        title={isMuted ? 'Unmute Atmosphere' : 'Mute Atmosphere'}
      >
        {isMuted ? (
          <VolumeX className="w-4 h-4 text-rose-400" />
        ) : (
          <Volume2 className="w-4 h-4 text-cyan-400" />
        )}
      </button>

      {/* Quick Volume Trigger / Mini slider */}
      <button
        onClick={() => setIsOpenVolume(!isOpenVolume)}
        className="text-[11px] font-mono text-slate-400 hover:text-slate-200"
      >
        {isMuted ? '0%' : `${volume}%`}
      </button>

      {isOpenVolume && (
        <div className="absolute right-0 top-10 p-2.5 rounded-xl bg-slate-900 border border-slate-700 shadow-xl backdrop-blur-xl z-50 flex items-center gap-2">
          <input
            type="range"
            min="0"
            max="100"
            value={isMuted ? 0 : volume}
            onChange={handleVolumeChange}
            className="w-24 accent-cyan-400 h-1 bg-slate-700 rounded-lg cursor-pointer"
          />
        </div>
      )}
    </div>
  );
};
