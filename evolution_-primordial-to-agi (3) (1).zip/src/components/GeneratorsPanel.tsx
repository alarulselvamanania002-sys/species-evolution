import React, { useState } from 'react';
import { Generator, EraId } from '../types';
import { ERAS } from '../data/evolutionData';
import { formatNumber } from '../utils/format';
import { 
  Sparkles, Flame, Sun, Bug, Footprints, Users, 
  BookOpen, Zap, Cpu, Bot, Atom, ArrowUpRight 
} from 'lucide-react';

interface GeneratorsPanelProps {
  generators: Generator[];
  entropy: number;
  ideas: number;
  currentEra: EraId;
  onBuyGenerator: (genId: string, count: number) => void;
}

const getGeneratorIcon = (iconName: string) => {
  switch (iconName) {
    case 'Sparkles': return <Sparkles className="w-5 h-5 text-orange-400" />;
    case 'Flame': return <Flame className="w-5 h-5 text-cyan-400" />;
    case 'Sun': return <Sun className="w-5 h-5 text-emerald-400" />;
    case 'Bug': return <Bug className="w-5 h-5 text-teal-400" />;
    case 'Footprints': return <Footprints className="w-5 h-5 text-lime-400" />;
    case 'Users': return <Users className="w-5 h-5 text-amber-400" />;
    case 'BookOpen': return <BookOpen className="w-5 h-5 text-yellow-400" />;
    case 'Zap': return <Zap className="w-5 h-5 text-blue-400" />;
    case 'Cpu': return <Cpu className="w-5 h-5 text-indigo-400" />;
    case 'Bot': return <Bot className="w-5 h-5 text-purple-400" />;
    case 'Atom': return <Atom className="w-5 h-5 text-fuchsia-400" />;
    default: return <Sparkles className="w-5 h-5 text-cyan-400" />;
  }
};

export const GeneratorsPanel: React.FC<GeneratorsPanelProps> = ({
  generators,
  entropy,
  ideas,
  currentEra,
  onBuyGenerator,
}) => {
  const [buyMultiplier, setBuyMultiplier] = useState<1 | 10 | 100>(1);

  // Compute total cost for N purchases
  const calculateTotalCost = (gen: Generator, amount: number) => {
    let total = 0;
    for (let i = 0; i < amount; i++) {
      total += gen.baseCost * Math.pow(gen.costMultiplier, gen.count + i);
    }
    return Math.floor(total);
  };

  return (
    <div className="w-full flex flex-col bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 md:p-5 backdrop-blur-xl shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800/80">
        <div>
          <h3 className="text-sm md:text-base font-bold text-slate-100 font-display flex items-center gap-2">
            <span>Life Forms & Inventions</span>
          </h3>
          <p className="text-xs text-slate-400">
            Self-replicating agents fueling planetary momentum
          </p>
        </div>

        {/* Multiplier Toggles */}
        <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
          {([1, 10, 100] as const).map((mul) => (
            <button
              key={mul}
              onClick={() => setBuyMultiplier(mul)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
                buyMultiplier === mul
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              x{mul}
            </button>
          ))}
        </div>
      </div>

      {/* List of Generators */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[480px] overflow-y-auto pr-1">
        {generators.map((gen) => {
          const cost = calculateTotalCost(gen, buyMultiplier);
          const userBalance = gen.currency === 'entropy' ? entropy : ideas;
          const affordable = userBalance >= cost;
          const currentProduction = gen.count * gen.baseProduction;
          const eraData = ERAS[gen.era];

          return (
            <div
              key={gen.id}
              className={`flex flex-col justify-between p-3.5 rounded-xl border transition-all duration-150 ${
                gen.count > 0
                  ? 'bg-slate-950/70 border-slate-800/90 hover:border-slate-700'
                  : 'bg-slate-950/40 border-slate-800/50 opacity-80'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                    {getGeneratorIcon(gen.iconName)}
                  </div>
                  <div>
                    <h4 className="text-xs md:text-sm font-bold text-slate-100">
                      {gen.name}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="font-mono text-cyan-300 font-medium">
                        +{formatNumber(gen.baseProduction)} {gen.productionType === 'entropy' ? 'S' : 'Ψ'}/s
                      </span>
                    </div>
                  </div>
                </div>

                <span className="text-base md:text-lg font-mono font-extrabold text-slate-300 bg-slate-900/80 px-2 py-0.5 rounded-lg border border-slate-800">
                  {gen.count}
                </span>
              </div>

              <p className="text-[11px] text-slate-400 line-clamp-1 mb-3">
                {gen.description}
              </p>

              {/* Total output and Buy Button */}
              <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-900/80">
                <div className="text-[10px] font-mono text-slate-400">
                  Total: <span className="text-slate-200 font-bold">{formatNumber(currentProduction)}</span>/s
                </div>

                <button
                  onClick={() => onBuyGenerator(gen.id, buyMultiplier)}
                  disabled={!affordable}
                  className={`py-1.5 px-3 rounded-lg text-xs font-bold font-mono transition-all flex items-center gap-1.5 ${
                    affordable
                      ? 'bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 active:scale-95 shadow-sm'
                      : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                  }`}
                >
                  <span>Buy x{buyMultiplier}</span>
                  <span>({formatNumber(cost)} {gen.currency === 'entropy' ? 'S' : 'Ψ'})</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
