import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { EraId } from '../types';
import { ERAS } from '../data/evolutionData';
import { soundEngine } from '../audio/soundtrack';
import { formatNumber } from '../utils/format';
import { Globe, Zap, ArrowRight, Sparkles, Check } from 'lucide-react';

interface EraMilestoneModalProps {
  eraId: EraId | null;
  onClose: () => void;
}

export const EraMilestoneModal: React.FC<EraMilestoneModalProps> = ({
  eraId,
  onClose,
}) => {
  useEffect(() => {
    if (eraId) {
      soundEngine.playMilestoneChime();

      // Launch celebration confetti
      const info = ERAS[eraId];
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 },
        colors: [info.color, '#38bdf8', '#fbbf24', '#ffffff'],
      });
    }
  }, [eraId]);

  if (!eraId) return null;

  const info = ERAS[eraId];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div 
        className="relative max-w-md w-full bg-slate-900 border rounded-3xl p-6 md:p-7 shadow-2xl overflow-hidden"
        style={{ borderColor: info.color + '88', boxShadow: `0 0 40px ${info.glowColor}` }}
      >
        {/* Glow ambient circle */}
        <div 
          className="absolute -top-20 -right-20 w-48 h-48 rounded-full blur-3xl pointer-events-none opacity-40"
          style={{ backgroundColor: info.color }}
        />

        {/* Top Header */}
        <div className="flex items-center gap-3 mb-4">
          <div 
            className="w-12 h-12 rounded-2xl flex items-center justify-center border shadow-lg"
            style={{ 
              backgroundColor: info.color + '22', 
              borderColor: info.color + '66',
              color: info.color,
            }}
          >
            <Globe className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="text-[11px] font-mono uppercase tracking-widest text-slate-400 font-bold">
              Planetary Evolution Milestone
            </div>
            <h2 className="text-xl font-extrabold text-white font-display">
              {info.name}
            </h2>
          </div>
        </div>

        {/* Subtitle & Description */}
        <div className="text-xs text-slate-300 font-medium mb-4 italic">
          {info.subtitle}
        </div>
        <p className="text-xs text-slate-400 leading-relaxed mb-6 bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80">
          {info.description}
        </p>

        {/* Big Surge Rewards Box */}
        <div className="flex flex-col gap-2.5 mb-6">
          <div className="text-[11px] uppercase font-bold tracking-wider text-slate-300 font-mono flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Ascension Surges Granted</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Instant Entropy Grant */}
            <div className="flex flex-col p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 font-mono">Instant Entropy Surge</span>
              <span className="text-base font-extrabold text-cyan-300 font-mono">
                +{formatNumber(info.instantRewardEntropy)} S
              </span>
              <span className="text-[9px] text-slate-500">Credited to balance immediately</span>
            </div>

            {/* Global Multiplier */}
            <div className="flex flex-col p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 font-mono">Global Era Multiplier</span>
              <span className="text-base font-extrabold font-mono" style={{ color: info.color }}>
                {info.eraMultiplier}x Speed
              </span>
              <span className="text-[9px] text-slate-500">Passive generation & clicks</span>
            </div>
          </div>
        </div>

        {/* Claim / Continue Button */}
        <button
          onClick={onClose}
          className="w-full py-3 px-4 rounded-xl text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-98 hover:brightness-110"
          style={{ backgroundColor: info.color }}
        >
          <span>Claim Ascension Surge &amp; Advance</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
