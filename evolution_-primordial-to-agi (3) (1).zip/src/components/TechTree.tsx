import React, { useState, useRef } from 'react';
import { TechNode, EraId } from '../types';
import { ERAS } from '../data/evolutionData';
import { formatNumber } from '../utils/format';
import { 
  Dna, CircleDot, Binary, Droplet, Sun, Sparkle, Layers, Eye, Shield, 
  Trees, Wind, Egg, Brain, Flame, MessageSquare, Wheat, Hammer, 
  Compass, Factory, Radio, Cpu, Globe, Network, Atom, RefreshCw, 
  Orbit, Check, Lock, ZoomIn, ZoomOut, Move, Info, Sparkles
} from 'lucide-react';

interface TechTreeProps {
  nodes: TechNode[];
  entropy: number;
  ideas: number;
  onBuyNode: (nodeId: string) => void;
  currentEra: EraId;
}

// Icon mapper helper
const getIcon = (name: string, className: string = 'w-5 h-5') => {
  switch (name) {
    case 'Dna': return <Dna className={className} />;
    case 'CircleDot': return <CircleDot className={className} />;
    case 'Binary': return <Binary className={className} />;
    case 'Droplet': return <Droplet className={className} />;
    case 'Sun': return <Sun className={className} />;
    case 'Sparkle': return <Sparkle className={className} />;
    case 'Layers': return <Layers className={className} />;
    case 'Eye': return <Eye className={className} />;
    case 'Shield': return <Shield className={className} />;
    case 'Trees': return <Trees className={className} />;
    case 'Wind': return <Wind className={className} />;
    case 'Egg': return <Egg className={className} />;
    case 'Brain': return <Brain className={className} />;
    case 'Flame': return <Flame className={className} />;
    case 'MessageSquare': return <MessageSquare className={className} />;
    case 'Wheat': return <Wheat className={className} />;
    case 'Hammer': return <Hammer className={className} />;
    case 'Compass': return <Compass className={className} />;
    case 'Factory': return <Factory className={className} />;
    case 'Radio': return <Radio className={className} />;
    case 'Cpu': return <Cpu className={className} />;
    case 'Globe': return <Globe className={className} />;
    case 'Network': return <Network className={className} />;
    case 'Atom': return <Atom className={className} />;
    case 'RefreshCw': return <RefreshCw className={className} />;
    case 'Orbit': return <Orbit className={className} />;
    default: return <Sparkles className={className} />;
  }
};

export const TechTree: React.FC<TechTreeProps> = ({
  nodes,
  entropy,
  ideas,
  onBuyNode,
  currentEra,
}) => {
  const [selectedNode, setSelectedNode] = useState<TechNode | null>(nodes[0] || null);
  const [zoom, setZoom] = useState<number>(0.85);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 40, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const startPan = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Filter category
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const handleMouseDown = (e: React.MouseEvent) => {
    // Only pan if clicking background
    if ((e.target as HTMLElement).closest('.tech-node-item')) return;
    setIsPanning(true);
    startPan.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPanning) return;
    setPan({
      x: e.clientX - startPan.current.x,
      y: e.clientY - startPan.current.y,
    });
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  const handleZoom = (delta: number) => {
    setZoom((prev) => Math.max(0.4, Math.min(1.4, prev + delta)));
  };

  const resetView = () => {
    setZoom(0.85);
    setPan({ x: 40, y: 0 });
  };

  // Check if a node is purchasable
  const canAfford = (node: TechNode) => {
    if (node.purchased) return false;
    if (node.entropyCost > entropy) return false;
    if (node.ideasCost && node.ideasCost > ideas) return false;
    return true;
  };

  // Node connection paths
  const connections: { from: TechNode; to: TechNode; isUnlocked: boolean }[] = [];
  const nodeMap = new Map<string, TechNode>();
  nodes.forEach((n) => nodeMap.set(n.id, n));

  nodes.forEach((node) => {
    node.prerequisites.forEach((prereqId) => {
      const parent = nodeMap.get(prereqId);
      if (parent) {
        connections.push({
          from: parent,
          to: node,
          isUnlocked: parent.purchased,
        });
      }
    });
  });

  const filteredNodes = categoryFilter === 'all' 
    ? nodes 
    : nodes.filter((n) => n.category === categoryFilter);

  return (
    <div className="relative w-full h-[620px] rounded-2xl bg-slate-950/80 border border-slate-800/80 overflow-hidden flex flex-col backdrop-blur-xl shadow-2xl">
      {/* Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-slate-900/90 border-b border-slate-800/80 z-20">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
          <h2 className="text-sm md:text-base font-bold tracking-wide text-slate-100 flex items-center gap-2 font-display">
            The Evolutionary & Tech Tree
          </h2>
          <span className="hidden sm:inline text-xs text-slate-400 font-mono">
            [{nodes.filter(n => n.purchased).length}/{nodes.length} Transcended]
          </span>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1 overflow-x-auto py-1 text-xs">
          {[
            { id: 'all', label: 'All Branches' },
            { id: 'organic', label: 'Prebiotic' },
            { id: 'biological', label: 'Biosphere' },
            { id: 'cognitive', label: 'Cognition' },
            { id: 'civilization', label: 'Civilization' },
            { id: 'digital', label: 'Silicon' },
            { id: 'singularity', label: 'Singularity' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                categoryFilter === cat.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => handleZoom(0.15)}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleZoom(-0.15)}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={resetView}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors"
            title="Reset View"
          >
            <Move className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div
        ref={containerRef}
        className="relative flex-1 cursor-grab active:cursor-grabbing overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900/40 via-slate-950 to-[#02050f]"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Subtle coordinate grid background */}
        <div
          className="absolute inset-0 pointer-events-none opacity-20"
          style={{
            backgroundImage: `radial-gradient(circle, #38bdf8 1px, transparent 1px)`,
            backgroundSize: `${30 * zoom}px ${30 * zoom}px`,
            backgroundPosition: `${pan.x}px ${pan.y}px`,
          }}
        />

        {/* World container affected by Pan & Zoom */}
        <div
          className="absolute origin-top-left transition-transform duration-75"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            width: '3200px',
            height: '700px',
          }}
        >
          {/* SVG Connection Lines */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
            <defs>
              <linearGradient id="line-active" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.8" />
              </linearGradient>
              <linearGradient id="line-singularity" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#a855f7" stopOpacity="1" />
              </linearGradient>
            </defs>

            {connections.map((conn, idx) => {
              const x1 = conn.from.position.x + 32;
              const y1 = conn.from.position.y + 32;
              const x2 = conn.to.position.x + 32;
              const y2 = conn.to.position.y + 32;

              // Smooth bezier curve
              const dx = (x2 - x1) * 0.5;
              const pathData = `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;

              const isPurchased = conn.from.purchased && conn.to.purchased;
              const isSingularity = conn.to.category === 'singularity';

              return (
                <g key={`conn-${idx}`}>
                  <path
                    d={pathData}
                    fill="none"
                    stroke={
                      isPurchased
                        ? isSingularity
                          ? 'url(#line-singularity)'
                          : 'url(#line-active)'
                        : conn.isUnlocked
                        ? 'rgba(100, 116, 139, 0.4)'
                        : 'rgba(51, 65, 85, 0.2)'
                    }
                    strokeWidth={isPurchased ? 3 : 1.8}
                    strokeDasharray={isPurchased ? 'none' : '4 4'}
                    className={isPurchased ? 'filter drop-shadow-[0_0_4px_rgba(6,182,212,0.4)]' : ''}
                  />
                  {isPurchased && (
                    <circle r="3" fill="#ffffff" className="filter drop-shadow-[0_0_4px_#38bdf8]">
                      <animateMotion path={pathData} dur="4s" repeatCount="indefinite" />
                    </circle>
                  )}
                </g>
              );
            })}
          </svg>

          {/* Render Nodes */}
          {filteredNodes.map((node) => {
            const era = ERAS[node.era];
            const isAffordable = canAfford(node);
            const isSelected = selectedNode?.id === node.id;
            const isSingularity = node.category === 'singularity';

            return (
              <div
                key={node.id}
                className="tech-node-item absolute z-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200"
                style={{
                  left: node.position.x + 32,
                  top: node.position.y + 32,
                }}
                onClick={() => setSelectedNode(node)}
              >
                <div
                  className={`relative flex flex-col items-center group`}
                >
                  {/* Outer glowing ring */}
                  <div
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-300 ${
                      node.purchased
                        ? isSingularity
                          ? 'bg-purple-950/80 border-2 border-purple-400 shadow-[0_0_18px_rgba(168,85,247,0.6)] text-purple-200'
                          : 'bg-cyan-950/80 border-2 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.5)] text-cyan-200'
                        : node.unlocked
                        ? isAffordable
                          ? 'bg-slate-900 border-2 border-amber-400/80 text-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.3)] animate-pulse'
                          : 'bg-slate-900/90 border border-slate-600 text-slate-300 hover:border-slate-400'
                        : 'bg-slate-950/90 border border-slate-800 text-slate-600 opacity-60'
                    } ${isSelected ? 'ring-4 ring-white/50 scale-110' : 'hover:scale-105'}`}
                  >
                    {/* Node Icon */}
                    {node.purchased ? (
                      <div className="relative">
                        {getIcon(node.iconName, 'w-7 h-7')}
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center text-white">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </div>
                      </div>
                    ) : node.unlocked ? (
                      getIcon(node.iconName, 'w-7 h-7')
                    ) : (
                      <Lock className="w-5 h-5 text-slate-500" />
                    )}
                  </div>

                  {/* Node Label underneath */}
                  <div className="mt-2 text-center max-w-[110px]">
                    <div
                      className={`text-xs font-semibold leading-tight line-clamp-2 ${
                        node.purchased
                          ? 'text-slate-100 font-medium'
                          : node.unlocked
                          ? 'text-slate-300'
                          : 'text-slate-600'
                      }`}
                    >
                      {node.name}
                    </div>

                    {!node.purchased && node.unlocked && (
                      <div
                        className={`text-[10px] font-mono mt-0.5 font-bold ${
                          isAffordable ? 'text-amber-400' : 'text-slate-400'
                        }`}
                      >
                        {formatNumber(node.entropyCost)} S
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Floating Details Drawer / Modal when a node is selected */}
        {selectedNode && (
          <div className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 rounded-2xl bg-slate-900/95 border border-slate-700/80 p-5 shadow-2xl backdrop-blur-xl z-30 animate-in fade-in slide-in-from-bottom-3 duration-200">
            <div className="flex items-start justify-between gap-2 mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border"
                    style={{
                      borderColor: ERAS[selectedNode.era].color + '66',
                      color: ERAS[selectedNode.era].color,
                      backgroundColor: ERAS[selectedNode.era].color + '15',
                    }}
                  >
                    {ERAS[selectedNode.era].name}
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                    {selectedNode.category}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white mt-1 font-display">
                  {selectedNode.name}
                </h3>
              </div>

              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border"
                style={{
                  borderColor: ERAS[selectedNode.era].color + '66',
                  backgroundColor: ERAS[selectedNode.era].color + '22',
                  color: ERAS[selectedNode.era].color,
                }}
              >
                {getIcon(selectedNode.iconName, 'w-5 h-5')}
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              {selectedNode.description}
            </p>

            {/* Scientific Fact Quote */}
            <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 mb-3.5 text-[11px] text-slate-400 italic flex items-start gap-2">
              <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5 not-italic" />
              <span>&ldquo;{selectedNode.scientificFact}&rdquo;</span>
            </div>

            {/* Multiplier Badges */}
            <div className="grid grid-cols-2 gap-2 mb-4 text-xs font-mono">
              {selectedNode.clickMultiplier && (
                <div className="px-2.5 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700/40 text-emerald-400">
                  Click Power: +{selectedNode.clickMultiplier}x
                </div>
              )}
              {selectedNode.entropyMultiplier && (
                <div className="px-2.5 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700/40 text-cyan-400">
                  Entropy Rate: +{selectedNode.entropyMultiplier}x
                </div>
              )}
              {selectedNode.ideasMultiplier && (
                <div className="px-2.5 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700/40 text-amber-400">
                  Ideas Rate: +{selectedNode.ideasMultiplier}x
                </div>
              )}
              {selectedNode.specialEffect && (
                <div className="col-span-2 px-2.5 py-1.5 rounded-lg bg-purple-950/50 border border-purple-800/50 text-purple-300 text-[11px]">
                  ✨ {selectedNode.specialEffect}
                </div>
              )}
            </div>

            {/* Purchase / Unlocked Action */}
            {selectedNode.purchased ? (
              <div className="w-full py-2.5 px-4 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-center text-xs font-bold flex items-center justify-center gap-2">
                <Check className="w-4 h-4" />
                Evolutionary Trait Unlocked & Transcended
              </div>
            ) : selectedNode.unlocked ? (
              <button
                onClick={() => onBuyNode(selectedNode.id)}
                disabled={!canAfford(selectedNode)}
                className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-between transition-all ${
                  canAfford(selectedNode)
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25 cursor-pointer active:scale-98'
                    : 'bg-slate-800 text-slate-500 border border-slate-700/40 cursor-not-allowed'
                }`}
              >
                <span>Synthesize Trait</span>
                <span className="font-mono">
                  {formatNumber(selectedNode.entropyCost)} Entropy
                  {selectedNode.ideasCost ? ` + ${formatNumber(selectedNode.ideasCost)} Ψ` : ''}
                </span>
              </button>
            ) : (
              <div className="w-full py-2.5 px-4 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-500 text-center text-xs font-medium flex items-center justify-center gap-2">
                <Lock className="w-3.5 h-3.5" />
                Requires preceding evolutionary steps
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
