import React from 'react';
import { GameState } from '../types';
import { formatNumber, formatTime } from '../utils/format';
import { ERAS } from '../data/evolutionData';
import { BarChart3, Clock, MousePointerClick, Zap, Sparkles, X, RotateCcw } from 'lucide-react';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  gameState: GameState;
  onResetGame: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  isOpen,
  onClose,
  gameState,
  onResetGame,
}) => {
  if (!isOpen) return null;

  const elapsedTime = (Date.now() - gameState.stats.startTime) / 1000;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700/80 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5 mb-5">
          <div className="p-2 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-400">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base md:text-lg font-bold text-white font-display">
              Planetary Statistics & Chronology
            </h3>
            <p className="text-xs text-slate-400">
              Telemetry of your cosmic evolutionary trajectory
            </p>
          </div>
        </div>

        {/* Metric Grid */}
        <div className="grid grid-cols-2 gap-3 mb-6 font-mono">
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Lifetime Entropy</span>
            </div>
            <div className="text-lg font-bold text-cyan-300">
              {formatNumber(gameState.totalEntropy)} S
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Lifetime Ideas</span>
            </div>
            <div className="text-lg font-bold text-amber-300">
              {formatNumber(gameState.totalIdeas)} Ψ
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
              <MousePointerClick className="w-3.5 h-3.5 text-emerald-400" />
              <span>Manual Planetary Taps</span>
            </div>
            <div className="text-lg font-bold text-emerald-300">
              {formatNumber(gameState.stats.totalClicks)}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-1">
              <Clock className="w-3.5 h-3.5 text-purple-400" />
              <span>Cosmic Run Duration</span>
            </div>
            <div className="text-lg font-bold text-purple-300">
              {formatTime(elapsedTime)}
            </div>
          </div>
        </div>

        {/* Current State Summary */}
        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 mb-6 space-y-2 text-xs">
          <div className="flex justify-between items-center text-slate-300">
            <span className="text-slate-400">Current Era:</span>
            <span className="font-bold font-display" style={{ color: ERAS[gameState.currentEra].color }}>
              {ERAS[gameState.currentEra].name}
            </span>
          </div>
          <div className="flex justify-between items-center text-slate-300">
            <span className="text-slate-400">Reality Flux Boost:</span>
            <span className="font-mono font-bold text-amber-400">
              +{gameState.realityFlux * 100}% Multiplier ({gameState.prestigeCount} Transferences)
            </span>
          </div>
          <div className="flex justify-between items-center text-slate-300">
            <span className="text-slate-400">Passive Rate:</span>
            <span className="font-mono text-cyan-400">
              {formatNumber(gameState.entropyPerSecond)} S/s &amp; {formatNumber(gameState.ideasPerSecond)} Ψ/s
            </span>
          </div>
        </div>

        {/* Danger zone reset */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">Restart from cosmic dawn?</span>
          <button
            onClick={() => {
              if (window.confirm('Reset all progress and start anew from the primordial Hadean void?')) {
                onResetGame();
                onClose();
              }
            }}
            className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Universe</span>
          </button>
        </div>
      </div>
    </div>
  );
};
