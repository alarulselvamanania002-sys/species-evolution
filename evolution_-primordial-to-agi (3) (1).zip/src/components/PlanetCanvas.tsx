import React, { useEffect, useRef, useState } from 'react';
import { EraId, FloatingText, Generator } from '../types';
import { ERAS } from '../data/evolutionData';
import { soundEngine } from '../audio/soundtrack';
import { formatNumber } from '../utils/format';
import { 
  Maximize2, Minimize2, Zap, Flame, Sparkles, Volume2, 
  VolumeX, ChevronUp, ChevronDown, Orbit, Globe, Bug, 
  Footprints, Users, BookOpen, Cpu, Bot, Atom
} from 'lucide-react';

interface PlanetCanvasProps {
  currentEra: EraId;
  clickPower: number;
  entropy: number;
  entropyPerSecond: number;
  ideas: number;
  ideasPerSecond: number;
  hasUnlockedIdeas: boolean;
  onPlanetTap: (point: { clientX: number; clientY: number; target: HTMLElement }) => void;
  floatingTexts: FloatingText[];
  isAgiBreakActive?: boolean;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  comboCount: number;
  comboMultiplier: number;
  generators?: Generator[];
  onBuyGenerator?: (genId: string, count: number) => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
}

const getQuickIcon = (iconName: string) => {
  switch (iconName) {
    case 'Sparkles': return <Sparkles className="w-3.5 h-3.5 text-orange-400" />;
    case 'Flame': return <Flame className="w-3.5 h-3.5 text-cyan-400" />;
    case 'Sun': return <Sparkles className="w-3.5 h-3.5 text-emerald-400" />;
    case 'Bug': return <Bug className="w-3.5 h-3.5 text-teal-400" />;
    case 'Footprints': return <Footprints className="w-3.5 h-3.5 text-lime-400" />;
    case 'Users': return <Users className="w-3.5 h-3.5 text-amber-400" />;
    case 'BookOpen': return <BookOpen className="w-3.5 h-3.5 text-yellow-400" />;
    case 'Zap': return <Zap className="w-3.5 h-3.5 text-blue-400" />;
    case 'Cpu': return <Cpu className="w-3.5 h-3.5 text-indigo-400" />;
    case 'Bot': return <Bot className="w-3.5 h-3.5 text-purple-400" />;
    case 'Atom': return <Atom className="w-3.5 h-3.5 text-fuchsia-400" />;
    default: return <Sparkles className="w-3.5 h-3.5 text-cyan-400" />;
  }
};

export const PlanetCanvas: React.FC<PlanetCanvasProps> = ({
  currentEra,
  clickPower,
  entropy,
  entropyPerSecond,
  ideas,
  ideasPerSecond,
  hasUnlockedIdeas,
  onPlanetTap,
  floatingTexts,
  isAgiBreakActive = false,
  isFullscreen,
  onToggleFullscreen,
  comboCount,
  comboMultiplier,
  generators = [],
  onBuyGenerator,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Rotation angles
  const rotX = useRef<number>(0.2); // pitch
  const rotY = useRef<number>(0);   // yaw
  const isDragging = useRef<boolean>(false);
  const pointerStartPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lastMousePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const particles = useRef<Particle[]>([]);
  const tapRipples = useRef<{ x: number; y: number; radius: number; maxRadius: number; alpha: number; color: string }[]>([]);

  // Fullscreen dock drawer state
  const [isQuickDockOpen, setIsQuickDockOpen] = useState<boolean>(true);
  const [buyMultiplier, setBuyMultiplier] = useState<1 | 10 | 100>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const eraInfo = ERAS[currentEra];

  // Spawn tap particles
  const spawnParticlesAt = (cx: number, cy: number, color: string) => {
    const count = 16;
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2.0 + Math.random() * 5.0;
      particles.current.push({
        x: cx,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1,
        maxLife: 0.6 + Math.random() * 0.4,
        size: 2.5 + Math.random() * 3.5,
        color: color,
      });
    }

    tapRipples.current.push({
      x: cx,
      y: cy,
      radius: 5,
      maxRadius: 85,
      alpha: 0.95,
      color: color,
    });
  };

  // Keyboard shortcut: Escape to exit fullscreen
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        onToggleFullscreen();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen, onToggleFullscreen]);

  // Pointer events for dragging
  const handlePointerDown = (e: React.PointerEvent) => {
    isDragging.current = true;
    pointerStartPos.current = { x: e.clientX, y: e.clientY };
    lastMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging.current) return;
    const dx = e.clientX - lastMousePos.current.x;
    const dy = e.clientY - lastMousePos.current.y;
    lastMousePos.current = { x: e.clientX, y: e.clientY };

    rotY.current += dx * 0.006;
    rotX.current = Math.max(-0.8, Math.min(0.8, rotX.current + dy * 0.006));
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    const totalDist = Math.hypot(
      e.clientX - pointerStartPos.current.x,
      e.clientY - pointerStartPos.current.y
    );
    isDragging.current = false;

    // If pointer didn't move significantly, consider it a tap!
    if (totalDist < 10 && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      spawnParticlesAt(x, y, eraInfo.color);
      soundEngine.playTapNote();
      onPlanetTap({ clientX: e.clientX, clientY: e.clientY, target: containerRef.current });
    }
  };

  // Multi-touch handler for smartphones, tablets, and touch screens
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();

    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      const x = touch.clientX - rect.left;
      const y = touch.clientY - rect.top;
      spawnParticlesAt(x, y, eraInfo.color);
      soundEngine.playTapNote();
      onPlanetTap({ clientX: touch.clientX, clientY: touch.clientY, target: containerRef.current });
    }
  };

  // Quick purchase calculation
  const calculateTotalCost = (gen: Generator, amount: number) => {
    let total = 0;
    for (let i = 0; i < amount; i++) {
      total += gen.baseCost * Math.pow(gen.costMultiplier, gen.count + i);
    }
    return Math.floor(total);
  };

  // Main canvas animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      // Auto rotate
      if (!isDragging.current) {
        rotY.current += 0.0035;
      }

      const dpr = window.devicePixelRatio || 1;
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;

      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      // In fullscreen, expand the sphere for monumental grandeur
      const radiusRatio = isFullscreen ? 0.38 : 0.33;
      const radius = Math.min(width, height) * radiusRatio;

      // 1. Draw Outer Atmospheric Glow
      const glowGrad = ctx.createRadialGradient(cx, cy, radius * 0.85, cx, cy, radius * 1.45);
      glowGrad.addColorStop(0, eraInfo.planetTheme.atmosphereColor);
      glowGrad.addColorStop(0.6, eraInfo.glowColor);
      glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.45, 0, Math.PI * 2);
      ctx.fillStyle = glowGrad;
      ctx.fill();

      // 2. Draw Sphere Base (Deep Space Shadow & Horizon)
      const baseGrad = ctx.createRadialGradient(
        cx - radius * 0.35,
        cy - radius * 0.35,
        radius * 0.1,
        cx,
        cy,
        radius
      );

      if (eraInfo.planetTheme.magmaCracks) {
        baseGrad.addColorStop(0, '#78350f');
        baseGrad.addColorStop(0.4, '#451a03');
        baseGrad.addColorStop(0.8, '#1c1917');
        baseGrad.addColorStop(1, '#0c0a09');
      } else {
        baseGrad.addColorStop(0, eraInfo.planetTheme.oceanColor);
        baseGrad.addColorStop(0.7, '#02182b');
        baseGrad.addColorStop(1, '#010811');
      }

      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.clip(); // Clip everything to the planet sphere!

      // Fill sphere base
      ctx.fillStyle = baseGrad;
      ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);

      // 3. Draw Continents / Magma Cracks / Land Formations using 3D projected math
      const yaw = rotY.current;
      const pitch = rotX.current;

      const numFeatures = currentEra === 'hadean' ? 24 : 32;
      for (let i = 0; i < numFeatures; i++) {
        const lat = ((i * 137.5) % 180 - 90) * (Math.PI / 180);
        const lon = (i * 73.17 + yaw * 57.3) * (Math.PI / 180);

        const x3 = Math.cos(lat) * Math.sin(lon);
        const y3 = Math.sin(lat);
        const z3 = Math.cos(lat) * Math.cos(lon);

        const cosP = Math.cos(pitch);
        const sinP = Math.sin(pitch);
        const yRot = y3 * cosP - z3 * sinP;
        const zRot = y3 * sinP + z3 * cosP;

        if (zRot > -0.15) {
          const px = cx + x3 * radius;
          const py = cy + yRot * radius;
          const scale = (zRot + 0.3) / 1.3;
          const featureRadius = (radius * 0.18 + (i % 5) * 8) * scale;

          if (eraInfo.planetTheme.magmaCracks) {
            ctx.beginPath();
            ctx.arc(px, py, featureRadius * 0.65, 0, Math.PI * 2);
            ctx.fillStyle = i % 2 === 0 ? '#ef4444' : '#f97316';
            ctx.shadowColor = '#fbbf24';
            ctx.shadowBlur = 10;
            ctx.fill();
            ctx.shadowBlur = 0;
          } else {
            ctx.beginPath();
            ctx.arc(px, py, featureRadius, 0, Math.PI * 2);
            ctx.fillStyle = eraInfo.planetTheme.landColor;
            ctx.globalAlpha = Math.min(1, Math.max(0.15, zRot));
            ctx.fill();
            ctx.globalAlpha = 1;

            if (eraInfo.planetTheme.hasCityLights && (px > cx + radius * 0.1 || i % 3 === 0)) {
              ctx.beginPath();
              ctx.arc(px + 4, py - 3, 2.5 * scale, 0, Math.PI * 2);
              ctx.fillStyle = '#fde047';
              ctx.shadowColor = '#f59e0b';
              ctx.shadowBlur = 6;
              ctx.fill();
              ctx.shadowBlur = 0;
            }
          }
        }
      }

      // 4. Digital Era Data Grid Lines
      if (eraInfo.planetTheme.hasDataGrid) {
        ctx.strokeStyle = currentEra === 'agi_breaking' ? 'rgba(192, 132, 252, 0.45)' : 'rgba(56, 189, 248, 0.35)';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 6]);

        for (let g = -2; g <= 2; g++) {
          const latY = cy + (g * radius) / 3.2;
          const chordHalfWidth = Math.sqrt(Math.max(0, radius * radius - Math.pow(latY - cy, 2)));
          ctx.beginPath();
          ctx.ellipse(cx, latY, chordHalfWidth, chordHalfWidth * 0.28, 0, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.setLineDash([]);
      }

      // 5. Cloud Layers
      if (!eraInfo.planetTheme.magmaCracks) {
        ctx.fillStyle = eraInfo.planetTheme.cloudColor;
        const cloudYaw = yaw * 1.35;
        for (let c = 0; c < 12; c++) {
          const cLat = ((c * 47) % 140 - 70) * (Math.PI / 180);
          const cLon = (c * 89 + cloudYaw * 57.3) * (Math.PI / 180);
          const cx3 = Math.cos(cLat) * Math.sin(cLon);
          const cy3 = Math.sin(cLat);
          const cz3 = Math.cos(cLat) * Math.cos(cLon);

          if (cz3 > 0) {
            const cpx = cx + cx3 * (radius + 2);
            const cpy = cy + (cy3 * Math.cos(pitch) - cz3 * Math.sin(pitch)) * (radius + 2);
            ctx.beginPath();
            ctx.ellipse(cpx, cpy, radius * 0.22 * cz3, radius * 0.08 * cz3, 0.2, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      // 6. Day / Night Dynamic Planetary Shadow Shader
      const shadowGrad = ctx.createRadialGradient(
        cx - radius * 0.5,
        cy - radius * 0.5,
        radius * 0.2,
        cx,
        cy,
        radius
      );
      shadowGrad.addColorStop(0, 'rgba(255, 255, 255, 0.15)');
      shadowGrad.addColorStop(0.5, 'rgba(0, 0, 0, 0.0)');
      shadowGrad.addColorStop(0.85, 'rgba(0, 4, 16, 0.7)');
      shadowGrad.addColorStop(1, 'rgba(0, 2, 8, 0.95)');

      ctx.fillStyle = shadowGrad;
      ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);

      // 7. Atmospheric Rim Crescent (Sunlight scatter)
      const rimGrad = ctx.createRadialGradient(
        cx - radius * 0.45,
        cy - radius * 0.45,
        radius * 0.8,
        cx - radius * 0.45,
        cy - radius * 0.45,
        radius * 1.05
      );
      rimGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
      rimGrad.addColorStop(0.9, eraInfo.color + '66');
      rimGrad.addColorStop(1, '#ffffff');

      ctx.fillStyle = rimGrad;
      ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);

      ctx.restore(); // End planet sphere clipping

      // 8. Orbital Tech / AGI Dyson Rings (Drawn outside sphere)
      if (eraInfo.planetTheme.hasAgiRings || isAgiBreakActive) {
        ctx.save();
        ctx.translate(cx, cy);

        // Ring 1 (Inner Dyson Ring)
        ctx.rotate(rotY.current * 0.4);
        ctx.beginPath();
        ctx.ellipse(0, 0, radius * 1.48, radius * 0.38, Math.PI / 6, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(168, 85, 247, 0.75)';
        ctx.lineWidth = 2.5;
        ctx.shadowColor = '#c084fc';
        ctx.shadowBlur = 15;
        ctx.stroke();

        // Ring 2 (Outer Polar Quantum Ring)
        ctx.rotate(rotY.current * -0.6);
        ctx.beginPath();
        ctx.ellipse(0, 0, radius * 1.72, radius * 0.45, -Math.PI / 4, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.65)';
        ctx.lineWidth = 1.8;
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 12;
        ctx.stroke();

        // Singularity Swarm nodes
        for (let s = 0; s < 8; s++) {
          const angle = rotY.current * 1.2 + (s * Math.PI) / 4;
          const sx = Math.cos(angle) * (radius * 1.48);
          const sy = Math.sin(angle) * (radius * 0.38);
          ctx.beginPath();
          ctx.arc(sx, sy, 3, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = '#a855f7';
          ctx.shadowBlur = 10;
          ctx.fill();
        }

        ctx.restore();
      }

      // 9. Render Tap Ripples
      for (let r = tapRipples.current.length - 1; r >= 0; r--) {
        const rip = tapRipples.current[r];
        rip.radius += 2.8;
        rip.alpha -= 0.026;

        if (rip.alpha <= 0) {
          tapRipples.current.splice(r, 1);
          continue;
        }

        ctx.beginPath();
        ctx.arc(rip.x, rip.y, rip.radius, 0, Math.PI * 2);
        ctx.strokeStyle = rip.color;
        ctx.globalAlpha = rip.alpha;
        ctx.lineWidth = 2.5;
        ctx.stroke();
        ctx.globalAlpha = 1;
      }

      // 10. Render Spark Particles
      for (let p = particles.current.length - 1; p >= 0; p--) {
        const pt = particles.current[p];
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.life -= 0.024;

        if (pt.life <= 0) {
          particles.current.splice(p, 1);
          continue;
        }

        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.size * pt.life, 0, Math.PI * 2);
        ctx.fillStyle = pt.color;
        ctx.globalAlpha = pt.life;
        ctx.shadowColor = pt.color;
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1;
      }

      ctx.restore();
      animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [currentEra, eraInfo, isAgiBreakActive, isFullscreen]);

  return (
    <div
      ref={containerRef}
      id="planet-container"
      tabIndex={0}
      className={`relative flex items-center justify-center cursor-pointer select-none overflow-hidden transition-all duration-300 ${
        isFullscreen
          ? 'fixed inset-0 z-50 w-screen h-screen bg-[#030712] flex-col'
          : 'w-full h-[440px] md:h-[540px] rounded-3xl bg-gradient-to-b from-slate-950/60 via-slate-900/40 to-black/80 border border-slate-800/80 shadow-2xl backdrop-blur-md'
      }`}
      style={{ touchAction: 'none' }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onTouchStart={handleTouchStart}
    >
      {/* Background Starfield Ambient Points */}
      <div className="absolute inset-0 pointer-events-none opacity-50">
        <div className="absolute top-1/4 left-1/6 w-1 h-1 bg-white rounded-full animate-pulse" />
        <div className="absolute top-3/4 left-1/3 w-1.5 h-1.5 bg-cyan-200 rounded-full animate-pulse" style={{ animationDelay: '1.2s' }} />
        <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-violet-200 rounded-full animate-pulse" style={{ animationDelay: '0.7s' }} />
        <div className="absolute bottom-1/4 right-1/6 w-1.5 h-1.5 bg-amber-100 rounded-full animate-pulse" style={{ animationDelay: '2.1s' }} />
        <div className="absolute top-1/2 right-1/12 w-1 h-1 bg-blue-300 rounded-full animate-pulse" style={{ animationDelay: '1.8s' }} />
      </div>

      {/* Main 3D Projected Canvas */}
      <canvas
        ref={canvasRef}
        id="planet-canvas"
        className="w-full h-full block"
      />

      {/* Fullscreen Overlay HUD Header */}
      {isFullscreen ? (
        <div className="absolute top-0 left-0 right-0 z-20 flex flex-wrap items-center justify-between gap-3 p-4 md:p-6 bg-gradient-to-b from-slate-950/95 via-slate-950/70 to-transparent pointer-events-auto">
          {/* Era Information Badge */}
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-2xl flex items-center justify-center border shadow-lg backdrop-blur-md"
              style={{
                backgroundColor: eraInfo.color + '25',
                borderColor: eraInfo.color + '60',
                color: eraInfo.color,
              }}
            >
              <Globe className="w-5 h-5 animate-spin" style={{ animationDuration: '30s' }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-slate-400">
                  Fullscreen Immersion &bull; Epoch {eraInfo.name}
                </span>
                <span 
                  className="text-[10px] font-mono font-extrabold px-2 py-0.5 rounded-full border"
                  style={{
                    color: eraInfo.color,
                    borderColor: eraInfo.color + '55',
                    backgroundColor: eraInfo.color + '15',
                  }}
                >
                  {eraInfo.eraMultiplier}x Speed
                </span>
              </div>
              <div className="text-xs text-slate-300 font-medium">
                {eraInfo.subtitle}
              </div>
            </div>
          </div>

          {/* Central Stats Readout in Fullscreen */}
          <div className="flex items-center gap-4 bg-slate-900/90 border border-slate-800/90 px-4 py-2 rounded-2xl shadow-xl backdrop-blur-xl font-mono">
            {/* Entropy */}
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee] animate-pulse" />
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 leading-none">Entropy (S)</span>
                <span className="text-base md:text-lg font-black text-cyan-300 tracking-tight">
                  {formatNumber(entropy)}
                </span>
              </div>
              <span className="text-[11px] text-cyan-400 font-bold self-end mb-0.5">
                (+{formatNumber(entropyPerSecond)}/s)
              </span>
            </div>

            {/* Ideas (if unlocked) */}
            {hasUnlockedIdeas && (
              <>
                <div className="w-px h-6 bg-slate-800" />
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_10px_#fbbf24]" />
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-400 leading-none">Ideas (Ψ)</span>
                    <span className="text-base md:text-lg font-black text-amber-300 tracking-tight">
                      {formatNumber(ideas)}
                    </span>
                  </div>
                  <span className="text-[11px] text-amber-400 font-bold self-end mb-0.5">
                    (+{formatNumber(ideasPerSecond)}/s)
                  </span>
                </div>
              </>
            )}

            {/* Tap Combo Power */}
            <div className="w-px h-6 bg-slate-800" />
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-400">Tap:</span>
              <span className="text-xs font-bold text-emerald-400">
                +{formatNumber(clickPower)} S
              </span>
              {comboCount > 1 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold animate-pulse">
                  {comboMultiplier.toFixed(1)}x
                </span>
              )}
            </div>
          </div>

          {/* Controls: Audio & Exit Fullscreen */}
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                const nextMute = soundEngine.toggleMute();
                setIsMuted(nextMute);
              }}
              className="p-2.5 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 transition-colors backdrop-blur-md"
              title="Toggle Sound"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFullscreen();
              }}
              className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-xs border border-slate-600/60 shadow-lg backdrop-blur-md transition-all active:scale-95"
            >
              <Minimize2 className="w-4 h-4 text-cyan-300" />
              <span>Exit Fullscreen (Esc)</span>
            </button>
          </div>
        </div>
      ) : (
        /* Regular View Top Controls */
        <>
          {/* Tap Guidance Badge & Combo Indicator */}
          <div className="absolute top-4 left-4 pointer-events-none flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/60 text-xs font-medium text-slate-300 backdrop-blur-md shadow-lg">
            <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: eraInfo.color }} />
            <span>Tap planet to manifest Entropy</span>
            {comboCount > 2 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-amber-500/30 text-amber-300 text-[10px] font-mono font-extrabold flex items-center gap-1 border border-amber-500/40 animate-pulse">
                <Flame className="w-2.5 h-2.5" />
                <span>{comboCount} Combo ({comboMultiplier.toFixed(1)}x)</span>
              </span>
            )}
          </div>

          {/* Fullscreen Button in Standard View */}
          <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFullscreen();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/85 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/70 text-xs font-semibold backdrop-blur-md shadow-lg transition-all active:scale-95 group"
              title="Expand to Fullscreen Planet View"
            >
              <Maximize2 className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span>Full Screen Planet</span>
            </button>
          </div>
        </>
      )}

      {/* Rotation Instruction */}
      <div className="absolute bottom-4 right-4 pointer-events-none text-[11px] text-slate-400/80 px-2.5 py-1 rounded bg-black/50 border border-slate-800/60 backdrop-blur-sm">
        Drag to rotate &bull; Multi-finger tap supported
      </div>

      {/* Fullscreen Quick Purchase Dock */}
      {isFullscreen && generators.length > 0 && onBuyGenerator && (
        <div 
          className="absolute bottom-0 left-0 right-0 z-20 flex flex-col items-center pointer-events-auto bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent pt-3 pb-4 px-4"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Toggle Dock Button */}
          <button
            onClick={() => setIsQuickDockOpen(prev => !prev)}
            className="flex items-center gap-1 px-3 py-1 mb-2 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-[11px] font-bold text-slate-300 backdrop-blur-md transition-all shadow-md"
          >
            {isQuickDockOpen ? (
              <>
                <ChevronDown className="w-3.5 h-3.5 text-cyan-400" />
                <span>Hide Organisms Dock</span>
              </>
            ) : (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-cyan-400" />
                <span>Quick Organisms Dock</span>
              </>
            )}
          </button>

          {isQuickDockOpen && (
            <div className="max-w-5xl w-full bg-slate-900/90 border border-slate-800/90 rounded-2xl p-3 shadow-2xl backdrop-blur-xl flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2 pb-1.5 border-b border-slate-800/60">
                <div className="text-[11px] font-mono text-slate-300 font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Quick Evolve Life Forms</span>
                </div>

                {/* Multiplier buttons */}
                <div className="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-lg border border-slate-800">
                  {([1, 10, 100] as const).map((mul) => (
                    <button
                      key={mul}
                      onClick={() => setBuyMultiplier(mul)}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-all ${
                        buyMultiplier === mul
                          ? 'bg-cyan-500 text-slate-950 shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      x{mul}
                    </button>
                  ))}
                </div>
              </div>

              {/* Organism horizontal scroll cards */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {generators.map((gen) => {
                  const cost = calculateTotalCost(gen, buyMultiplier);
                  const userBalance = gen.currency === 'entropy' ? entropy : ideas;
                  const canAfford = userBalance >= cost;

                  return (
                    <button
                      key={gen.id}
                      onClick={() => onBuyGenerator(gen.id, buyMultiplier)}
                      disabled={!canAfford}
                      className={`flex-shrink-0 flex items-center gap-2.5 p-2 rounded-xl border transition-all text-left ${
                        canAfford
                          ? 'bg-slate-950/90 border-cyan-500/40 hover:border-cyan-400 hover:bg-slate-900 active:scale-95 shadow-sm'
                          : 'bg-slate-950/40 border-slate-800/40 opacity-50 cursor-not-allowed'
                      }`}
                      style={{ minWidth: '160px' }}
                    >
                      <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                        {getQuickIcon(gen.iconName)}
                      </div>
                      <div className="flex flex-col flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[11px] font-bold text-slate-200 truncate">
                            {gen.name}
                          </span>
                          <span className="text-[10px] font-mono font-extrabold text-cyan-400">
                            {gen.count}
                          </span>
                        </div>
                        <div className="text-[10px] font-mono text-slate-400">
                          {formatNumber(cost)} {gen.currency === 'entropy' ? 'S' : 'Ψ'}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Floating Click Numbers */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {floatingTexts.map((ft) => (
          <div
            key={ft.id}
            className="absolute font-mono font-extrabold text-sm md:text-lg transition-all duration-700 pointer-events-none animate-float-up drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]"
            style={{
              left: ft.x,
              top: ft.y,
              color: ft.color,
            }}
          >
            {ft.text}
          </div>
        ))}
      </div>
    </div>
  );
};
