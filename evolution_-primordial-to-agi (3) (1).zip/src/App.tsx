import React, { useState, useEffect, useRef, useCallback } from 'react';
import { EraId, FloatingText, GameState, Generator, TechNode } from './types';
import { ERAS, ERA_ORDER, INITIAL_GENERATORS, TECH_TREE_NODES } from './data/evolutionData';
import { PlanetCanvas } from './components/PlanetCanvas';
import { TechTree } from './components/TechTree';
import { GeneratorsPanel } from './components/GeneratorsPanel';
import { PlanetTimeline } from './components/PlanetTimeline';
import { AudioPlayerControls } from './components/AudioPlayerControls';
import { AgiAscensionModal } from './components/AgiAscensionModal';
import { StatsModal } from './components/StatsModal';
import { EraMilestoneModal } from './components/EraMilestoneModal';
import { soundEngine } from './audio/soundtrack';
import { formatNumber } from './utils/format';
import { 
  Globe, GitFork, BarChart2, Sparkles, Zap, Orbit, 
  Layers, Trophy, RefreshCw, Cpu, Maximize2, Minimize2, 
  Flame, LayoutGrid, Columns
} from 'lucide-react';

const STORAGE_KEY = 'evolution_game_save_v2';

export default function App() {
  // --- STATE ---
  const [entropy, setEntropy] = useState<number>(0);
  const [totalEntropy, setTotalEntropy] = useState<number>(0);
  const [ideas, setIdeas] = useState<number>(0);
  const [totalIdeas, setTotalIdeas] = useState<number>(0);
  const [currentEra, setCurrentEra] = useState<EraId>('hadean');
  const [unlockedEras, setUnlockedEras] = useState<EraId[]>(['hadean']);
  const [realityFlux, setRealityFlux] = useState<number>(0);
  const [prestigeCount, setPrestigeCount] = useState<number>(0);

  const [generators, setGenerators] = useState<Generator[]>(INITIAL_GENERATORS);
  const [nodes, setNodes] = useState<TechNode[]>(TECH_TREE_NODES);

  const [activeTab, setActiveTab] = useState<'planet' | 'tree'>('planet');
  const [planetViewMode, setPlanetViewMode] = useState<'split' | 'enlarged'>('split');
  const [isPlanetFullscreen, setIsPlanetFullscreen] = useState<boolean>(false);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [isAgiModalOpen, setIsAgiModalOpen] = useState<boolean>(false);
  const [isStatsModalOpen, setIsStatsModalOpen] = useState<boolean>(false);
  const [pendingMilestoneEra, setPendingMilestoneEra] = useState<EraId | null>(null);
  const [totalClicks, setTotalClicks] = useState<number>(0);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [hasUnlockedIdeas, setHasUnlockedIdeas] = useState<boolean>(false);

  // Combo mechanics for continuous rapid tapping
  const [comboCount, setComboCount] = useState<number>(0);
  const [comboMultiplier, setComboMultiplier] = useState<number>(1.0);
  const comboDecayTimer = useRef<number | null>(null);

  // Floating text id generator
  const nextTextId = useRef<number>(1);

  // --- DERIVED MULTIPLIERS ---
  const calculateRates = useCallback(() => {
    let clickMult = 1;
    let entropyMult = 1;
    let ideasMult = 1;

    // Purchased nodes bonuses
    nodes.forEach((n) => {
      if (n.purchased) {
        if (n.clickMultiplier) clickMult *= n.clickMultiplier;
        if (n.entropyMultiplier) entropyMult *= n.entropyMultiplier;
        if (n.ideasMultiplier) ideasMult *= n.ideasMultiplier;
      }
    });

    // Current Epoch Global Multiplier
    const currentEraInfo = ERAS[currentEra];
    const eraMult = currentEraInfo ? currentEraInfo.eraMultiplier : 1;
    entropyMult *= eraMult;
    ideasMult *= Math.max(1, Math.floor(Math.sqrt(eraMult)));

    // Prestige bonus (+100% per reality flux)
    const prestigeMultiplier = 1 + realityFlux * 1.0;
    clickMult *= prestigeMultiplier;
    entropyMult *= prestigeMultiplier;
    ideasMult *= prestigeMultiplier;

    // Passive Entropy/sec & Ideas/sec
    let passiveEntropy = 0;
    let passiveIdeas = 0;

    generators.forEach((gen) => {
      if (gen.count > 0) {
        if (gen.productionType === 'entropy') {
          passiveEntropy += gen.count * gen.baseProduction;
        } else {
          passiveIdeas += gen.count * gen.baseProduction;
        }
      }
    });

    const totalPassiveEntropy = passiveEntropy * entropyMult;
    const totalPassiveIdeas = passiveIdeas * ideasMult;

    // Dynamic Click Power:
    // Base 1 + 6% of passive entropy/sec, scaled by tech multipliers, prestige, and active combo multiplier!
    const dynamicClickBase = 1 + Math.floor(totalPassiveEntropy * 0.06);
    const clickPower = Math.max(1, Math.floor(dynamicClickBase * clickMult * comboMultiplier));

    return {
      clickPower,
      entropyPerSecond: totalPassiveEntropy,
      ideasPerSecond: totalPassiveIdeas,
    };
  }, [nodes, generators, realityFlux, currentEra, comboMultiplier]);

  const { clickPower, entropyPerSecond, ideasPerSecond } = calculateRates();

  // --- LOAD FROM LOCAL STORAGE ---
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('evolution_game_save_v1');
      if (saved) {
        const data = JSON.parse(saved);
        if (data.entropy !== undefined) setEntropy(data.entropy);
        if (data.totalEntropy !== undefined) setTotalEntropy(data.totalEntropy);
        if (data.ideas !== undefined) setIdeas(data.ideas);
        if (data.totalIdeas !== undefined) setTotalIdeas(data.totalIdeas);
        if (data.currentEra) setCurrentEra(data.currentEra);
        if (data.unlockedEras) setUnlockedEras(data.unlockedEras);
        if (data.realityFlux !== undefined) setRealityFlux(data.realityFlux);
        if (data.prestigeCount !== undefined) setPrestigeCount(data.prestigeCount);
        if (data.totalClicks !== undefined) setTotalClicks(data.totalClicks);
        if (data.startTime) setStartTime(data.startTime);
        if (data.hasUnlockedIdeas) setHasUnlockedIdeas(data.hasUnlockedIdeas);

        if (Array.isArray(data.generators)) {
          setGenerators(prev =>
            prev.map(g => {
              const match = data.generators.find((savedG: Generator) => savedG.id === g.id);
              return match ? { ...g, count: match.count } : g;
            })
          );
        }

        if (Array.isArray(data.nodes)) {
          setNodes(prev =>
            prev.map(n => {
              const match = data.nodes.find((savedN: TechNode) => savedN.id === n.id);
              return match ? { ...n, purchased: match.purchased, unlocked: match.unlocked } : n;
            })
          );
        }
      }
    } catch (e) {
      console.warn('Could not load saved game:', e);
    }
  }, []);

  // --- AUTOSAVE TO LOCAL STORAGE ---
  useEffect(() => {
    const saveInterval = setInterval(() => {
      try {
        const payload = {
          entropy,
          totalEntropy,
          ideas,
          totalIdeas,
          currentEra,
          unlockedEras,
          realityFlux,
          prestigeCount,
          totalClicks,
          startTime,
          hasUnlockedIdeas,
          generators: generators.map(g => ({ id: g.id, count: g.count })),
          nodes: nodes.map(n => ({ id: n.id, purchased: n.purchased, unlocked: n.unlocked })),
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
      } catch (e) {
        console.warn('Save failed:', e);
      }
    }, 4000);

    return () => clearInterval(saveInterval);
  }, [
    entropy, totalEntropy, ideas, totalIdeas, currentEra, unlockedEras,
    realityFlux, prestigeCount, totalClicks, startTime, hasUnlockedIdeas,
    generators, nodes
  ]);

  // --- PASSIVE GENERATION TICKER ---
  useEffect(() => {
    let lastTime = performance.now();

    const interval = setInterval(() => {
      const now = performance.now();
      const dt = (now - lastTime) / 1000;
      lastTime = now;

      if (entropyPerSecond > 0) {
        const addedEntropy = entropyPerSecond * dt;
        setEntropy(prev => prev + addedEntropy);
        setTotalEntropy(prev => prev + addedEntropy);
      }

      if (ideasPerSecond > 0) {
        const addedIdeas = ideasPerSecond * dt;
        setIdeas(prev => prev + addedIdeas);
        setTotalIdeas(prev => prev + addedIdeas);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [entropyPerSecond, ideasPerSecond]);

  // --- AUTOMATIC ERA UNLOCK CHECK WITH INSTANT SURGE REWARDS ---
  useEffect(() => {
    ERA_ORDER.forEach((eraId) => {
      const eraInfo = ERAS[eraId];
      if (totalEntropy >= eraInfo.requiredEntropy && !unlockedEras.includes(eraId)) {
        setUnlockedEras(prev => [...prev, eraId]);
        setCurrentEra(eraId);
        soundEngine.setEra(eraId);

        // Grant instant entropy milestone surge reward
        if (eraInfo.instantRewardEntropy > 0) {
          setEntropy(prev => prev + eraInfo.instantRewardEntropy);
          setTotalEntropy(prev => prev + eraInfo.instantRewardEntropy);
        }

        // Trigger Milestone celebration modal
        setPendingMilestoneEra(eraId);
      }
    });
  }, [totalEntropy, unlockedEras]);

  // --- CHECK UNLOCK OF TECH NODES ---
  useEffect(() => {
    setNodes(prevNodes => {
      const purchasedIds = new Set(prevNodes.filter(n => n.purchased).map(n => n.id));
      let changed = false;

      const next = prevNodes.map(node => {
        if (node.purchased || node.unlocked) return node;

        const allPrereqsMet = node.prerequisites.length === 0 ||
          node.prerequisites.every(id => purchasedIds.has(id));

        if (allPrereqsMet) {
          changed = true;
          return { ...node, unlocked: true };
        }
        return node;
      });

      return changed ? next : prevNodes;
    });
  }, [nodes]);

  // --- MANUAL PLANET TAP WITH MULTI-TOUCH & COMBO SURGE ---
  const handlePlanetTap = (point: { clientX: number; clientY: number; target: HTMLElement }) => {
    setEntropy(prev => prev + clickPower);
    setTotalEntropy(prev => prev + clickPower);
    setTotalClicks(prev => prev + 1);

    // Build combo streak
    setComboCount(prev => {
      const next = prev + 1;
      // Multiplier steps: up to 3.0x max
      const newMult = 1 + Math.min(2.0, next * 0.05);
      setComboMultiplier(newMult);
      return next;
    });

    // Reset combo decay timer
    if (comboDecayTimer.current) {
      window.clearTimeout(comboDecayTimer.current);
    }
    comboDecayTimer.current = window.setTimeout(() => {
      setComboCount(0);
      setComboMultiplier(1.0);
    }, 1600);

    const rect = point.target.getBoundingClientRect();
    const x = point.clientX - rect.left;
    const y = point.clientY - rect.top;

    const newId = nextTextId.current++;
    const eraInfo = ERAS[currentEra];

    setFloatingTexts(prev => [
      ...prev.slice(-24),
      {
        id: newId,
        x: Math.max(30, Math.min(rect.width - 30, x)),
        y: Math.max(30, Math.min(rect.height - 30, y)),
        text: `+${formatNumber(clickPower)} S`,
        color: eraInfo.color,
      },
    ]);

    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== newId));
    }, 850);
  };

  // --- BUY TECH NODE ---
  const handleBuyNode = (nodeId: string) => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node || node.purchased || !node.unlocked) return;

    if (entropy < node.entropyCost) return;
    if (node.ideasCost && ideas < node.ideasCost) return;

    setEntropy(prev => prev - node.entropyCost);
    if (node.ideasCost) {
      setIdeas(prev => prev - node.ideasCost!);
    }

    if (node.id === 'controlled_fire' || node.ideasCost || node.ideasMultiplier) {
      setHasUnlockedIdeas(true);
    }

    setNodes(prev =>
      prev.map(n => (n.id === nodeId ? { ...n, purchased: true } : n))
    );

    soundEngine.playUnlockSound();

    if (nodeId === 'agi_breaking_node') {
      setCurrentEra('agi_breaking');
      if (!unlockedEras.includes('agi_breaking')) {
        setUnlockedEras(prev => [...prev, 'agi_breaking']);
      }
      soundEngine.setEra('agi_breaking');
      setIsAgiModalOpen(true);
    }
  };

  // --- BUY GENERATOR ---
  const handleBuyGenerator = (genId: string, count: number) => {
    const gen = generators.find(g => g.id === genId);
    if (!gen) return;

    let totalCost = 0;
    for (let i = 0; i < count; i++) {
      totalCost += gen.baseCost * Math.pow(gen.costMultiplier, gen.count + i);
    }
    totalCost = Math.floor(totalCost);

    const userBalance = gen.currency === 'entropy' ? entropy : ideas;
    if (userBalance < totalCost) return;

    if (gen.currency === 'entropy') {
      setEntropy(prev => prev - totalCost);
    } else {
      setIdeas(prev => prev - totalCost);
    }

    setGenerators(prev =>
      prev.map(g => (g.id === genId ? { ...g, count: g.count + count } : g))
    );

    soundEngine.playTapNote();
  };

  // --- PRESTIGE (COSMIC TRANSFERENCE) ---
  const calculatedFlux = Math.max(1, Math.floor(Math.sqrt(totalEntropy / 500000000)));

  const handlePrestige = () => {
    setRealityFlux(prev => prev + calculatedFlux);
    setPrestigeCount(prev => prev + 1);

    // Reset loop
    setEntropy(0);
    setIdeas(0);
    setCurrentEra('hadean');
    setUnlockedEras(['hadean']);
    setHasUnlockedIdeas(false);
    setGenerators(INITIAL_GENERATORS);
    setNodes(TECH_TREE_NODES);

    setIsAgiModalOpen(false);
    soundEngine.setEra('hadean');
    soundEngine.playMilestoneChime();
  };

  // --- RESET UNIVERSE COMPLETELY ---
  const handleResetGame = () => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem('evolution_game_save_v1');
    setEntropy(0);
    setTotalEntropy(0);
    setIdeas(0);
    setTotalIdeas(0);
    setCurrentEra('hadean');
    setUnlockedEras(['hadean']);
    setRealityFlux(0);
    setPrestigeCount(0);
    setTotalClicks(0);
    setStartTime(Date.now());
    setHasUnlockedIdeas(false);
    setGenerators(INITIAL_GENERATORS);
    setNodes(TECH_TREE_NODES);
    soundEngine.setEra('hadean');
  };

  const isAgiBreakingEra = currentEra === 'agi_breaking';

  return (
    <div className={`min-h-screen flex flex-col text-slate-100 bg-[#030712] selection:bg-cyan-500/30 selection:text-cyan-200 transition-colors duration-700 ${
      isAgiBreakingEra ? 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-950/40 via-slate-950 to-black' : ''
    }`}>
      {/* Top Main Navigation Bar */}
      <header className="sticky top-0 z-40 w-full bg-slate-950/90 border-b border-slate-800/80 backdrop-blur-xl px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Logo & App Name */}
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center p-0.5 border ${
              isAgiBreakingEra 
                ? 'bg-purple-950 border-purple-400 text-purple-300 shadow-[0_0_15px_#c084fc]' 
                : 'bg-cyan-950 border-cyan-500/50 text-cyan-400'
            }`}>
              {isAgiBreakingEra ? (
                <Orbit className="w-5 h-5 animate-spin" style={{ animationDuration: '10s' }} />
              ) : (
                <Globe className="w-5 h-5 animate-pulse" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm md:text-base font-extrabold tracking-wide font-display text-white">
                  Evolution: Primordial to AGI
                </h1>
                {realityFlux > 0 && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                    Flux +{realityFlux * 100}%
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-400">
                Clicker &amp; Planetary Singularity Simulator
              </div>
            </div>
          </div>

          {/* Primary Currencies Bar */}
          <div className="flex items-center gap-4 bg-slate-900/90 border border-slate-800 px-4 py-1.5 rounded-2xl shadow-inner font-mono">
            {/* Entropy */}
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] animate-pulse" />
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 leading-none">Entropy (S)</span>
                <span className="text-sm md:text-base font-black text-cyan-300 tracking-tight">
                  {formatNumber(entropy)}
                </span>
              </div>
              <span className="text-[10px] text-cyan-400 font-bold self-end mb-0.5">
                (+{formatNumber(entropyPerSecond)}/s)
              </span>
            </div>

            {/* Ideas (Unlocked later) */}
            {(hasUnlockedIdeas || totalIdeas > 0 || totalEntropy > 2000000) && (
              <>
                <div className="w-px h-6 bg-slate-800" />
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-400 leading-none">Ideas (Ψ)</span>
                    <span className="text-sm md:text-base font-black text-amber-300 tracking-tight">
                      {formatNumber(ideas)}
                    </span>
                  </div>
                  <span className="text-[10px] text-amber-400 font-bold self-end mb-0.5">
                    (+{formatNumber(ideasPerSecond)}/s)
                  </span>
                </div>
              </>
            )}
          </div>

          {/* Toolbar: Fullscreen Planet, Soundtrack, Stats, Singularity */}
          <div className="flex items-center gap-2">
            {/* Fullscreen Planet Quick Button */}
            <button
              onClick={() => setIsPlanetFullscreen(prev => !prev)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/70 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-500/50 text-xs font-bold transition-all shadow-md active:scale-95"
              title="Toggle Immersive Fullscreen Planet View"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Fullscreen Planet</span>
            </button>

            <AudioPlayerControls currentEra={currentEra} />

            {/* Stats Trigger */}
            <button
              onClick={() => setIsStatsModalOpen(true)}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 transition-colors"
              title="Game Telemetry & History"
            >
              <BarChart2 className="w-4 h-4" />
            </button>

            {/* Singularity Trigger Button (if in AGI era) */}
            {isAgiBreakingEra && (
              <button
                onClick={() => setIsAgiModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-[0_0_12px_rgba(168,85,247,0.5)] animate-pulse"
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>Singularity</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col gap-5">
        {/* Planetary Timeline Progression */}
        <PlanetTimeline
          currentEra={currentEra}
          unlockedEras={unlockedEras}
          totalEntropy={totalEntropy}
          onSelectEra={(era) => {
            setCurrentEra(era);
            soundEngine.setEra(era);
          }}
        />

        {/* View Mode Switcher Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-1 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('planet')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all ${
                activeTab === 'planet'
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Globe className="w-4 h-4" />
              <span>Planet &amp; Biosphere</span>
            </button>

            <button
              onClick={() => setActiveTab('tree')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all ${
                activeTab === 'tree'
                  ? 'bg-slate-800 text-purple-300 border border-slate-700 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <GitFork className="w-4 h-4" />
              <span>Evolutionary &amp; Tech Tree</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-900 text-slate-300 border border-slate-800">
                {nodes.filter(n => n.purchased).length}/{nodes.length}
              </span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            {/* View layout mode toggle when on Planet tab */}
            {activeTab === 'planet' && (
              <div className="flex items-center gap-1 bg-slate-900/80 border border-slate-800 p-0.5 rounded-lg">
                <button
                  onClick={() => setPlanetViewMode('split')}
                  className={`px-2 py-1 rounded text-[11px] font-sans flex items-center gap-1 ${
                    planetViewMode === 'split' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Side-by-Side Split View"
                >
                  <Columns className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Split</span>
                </button>
                <button
                  onClick={() => setPlanetViewMode('enlarged')}
                  className={`px-2 py-1 rounded text-[11px] font-sans flex items-center gap-1 ${
                    planetViewMode === 'enlarged' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Large Planet Stage View"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Enlarged Planet</span>
                </button>
              </div>
            )}

            {/* Click Power and active combo indicator */}
            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-800/80 px-3 py-1 rounded-xl text-slate-400">
              <span>Tap: <strong className="text-emerald-400">+{formatNumber(clickPower)}</strong> S</span>
              {comboCount > 1 && (
                <span className="text-[11px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1 animate-pulse">
                  <Flame className="w-3 h-3 text-amber-400" />
                  <span>{comboMultiplier.toFixed(1)}x Surge</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* VIEW 1: PLANET & GENERATORS VIEW */}
        {activeTab === 'planet' ? (
          planetViewMode === 'split' ? (
            /* SPLIT VIEW (7 cols / 5 cols) */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
              {/* Left 7 Columns: 3D Interactive Planet Canvas */}
              <div className="lg:col-span-7 flex flex-col gap-4">
                <PlanetCanvas
                  currentEra={currentEra}
                  clickPower={clickPower}
                  entropy={entropy}
                  entropyPerSecond={entropyPerSecond}
                  ideas={ideas}
                  ideasPerSecond={ideasPerSecond}
                  hasUnlockedIdeas={hasUnlockedIdeas}
                  onPlanetTap={handlePlanetTap}
                  floatingTexts={floatingTexts}
                  isAgiBreakActive={isAgiBreakingEra}
                  isFullscreen={isPlanetFullscreen}
                  onToggleFullscreen={() => setIsPlanetFullscreen(prev => !prev)}
                  comboCount={comboCount}
                  comboMultiplier={comboMultiplier}
                  generators={generators}
                  onBuyGenerator={handleBuyGenerator}
                />

                {/* Epoch Details Card */}
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <h3 className="text-sm font-bold text-slate-200 font-display">
                      {ERAS[currentEra].subtitle}
                    </h3>
                    <span
                      className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full border"
                      style={{
                        color: ERAS[currentEra].color,
                        borderColor: ERAS[currentEra].color + '55',
                        backgroundColor: ERAS[currentEra].color + '15',
                      }}
                    >
                      Epoch {ERA_ORDER.indexOf(currentEra) + 1} of 8 &bull; {ERAS[currentEra].eraMultiplier}x Multiplier
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {ERAS[currentEra].description}
                  </p>
                </div>
              </div>

              {/* Right 5 Columns: Generators & Life Forms Panel */}
              <div className="lg:col-span-5">
                <GeneratorsPanel
                  generators={generators}
                  entropy={entropy}
                  ideas={ideas}
                  currentEra={currentEra}
                  onBuyGenerator={handleBuyGenerator}
                />
              </div>
            </div>
          ) : (
            /* ENLARGED PLANET STAGE VIEW (Full width stage + generators beneath) */
            <div className="flex flex-col gap-5">
              <PlanetCanvas
                currentEra={currentEra}
                clickPower={clickPower}
                entropy={entropy}
                entropyPerSecond={entropyPerSecond}
                ideas={ideas}
                ideasPerSecond={ideasPerSecond}
                hasUnlockedIdeas={hasUnlockedIdeas}
                onPlanetTap={handlePlanetTap}
                floatingTexts={floatingTexts}
                isAgiBreakActive={isAgiBreakingEra}
                isFullscreen={isPlanetFullscreen}
                onToggleFullscreen={() => setIsPlanetFullscreen(prev => !prev)}
                comboCount={comboCount}
                comboMultiplier={comboMultiplier}
                generators={generators}
                onBuyGenerator={handleBuyGenerator}
              />

              {/* Organisms Panel below enlarged canvas */}
              <GeneratorsPanel
                generators={generators}
                entropy={entropy}
                ideas={ideas}
                currentEra={currentEra}
                onBuyGenerator={handleBuyGenerator}
              />
            </div>
          )
        ) : (
          /* VIEW 2: INTERACTIVE TECH TREE VIEW */
          <div className="w-full flex flex-col gap-4">
            <TechTree
              nodes={nodes}
              entropy={entropy}
              ideas={ideas}
              onBuyNode={handleBuyNode}
              currentEra={currentEra}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="w-full py-3 px-4 border-t border-slate-900 text-center text-slate-500 text-xs font-mono">
        Evolution: Primordial to AGI &bull; Tap for Entropy &bull; Terraform Planets &bull; Unlock the Singularity
      </footer>

      {/* Fullscreen Planet Canvas Render when isPlanetFullscreen is active outside main flow */}
      {isPlanetFullscreen && (
        <PlanetCanvas
          currentEra={currentEra}
          clickPower={clickPower}
          entropy={entropy}
          entropyPerSecond={entropyPerSecond}
          ideas={ideas}
          ideasPerSecond={ideasPerSecond}
          hasUnlockedIdeas={hasUnlockedIdeas}
          onPlanetTap={handlePlanetTap}
          floatingTexts={floatingTexts}
          isAgiBreakActive={isAgiBreakingEra}
          isFullscreen={isPlanetFullscreen}
          onToggleFullscreen={() => setIsPlanetFullscreen(false)}
          comboCount={comboCount}
          comboMultiplier={comboMultiplier}
          generators={generators}
          onBuyGenerator={handleBuyGenerator}
        />
      )}

      {/* Epoch Milestone Ascension Surge Celebration Modal */}
      <EraMilestoneModal
        eraId={pendingMilestoneEra}
        onClose={() => setPendingMilestoneEra(null)}
      />

      {/* The Breaking of AGI Climax Modal */}
      <AgiAscensionModal
        isOpen={isAgiModalOpen}
        onClose={() => setIsAgiModalOpen(false)}
        onPrestige={handlePrestige}
        totalLifetimeEntropy={totalEntropy}
        calculatedFlux={calculatedFlux}
        currentPrestigeCount={prestigeCount}
      />

      {/* Telemetry & Stats Modal */}
      <StatsModal
        isOpen={isStatsModalOpen}
        onClose={() => setIsStatsModalOpen(false)}
        gameState={{
          entropy,
          totalEntropy,
          ideas,
          totalIdeas,
          entropyPerSecond,
          ideasPerSecond,
          clickPower,
          currentEra,
          unlockedEras,
          realityFlux,
          prestigeCount,
          agiBreakTriggered: isAgiBreakingEra,
          soundtrackMuted: false,
          soundtrackVolume: 0.45,
          soundEffectsVolume: 0.5,
          stats: {
            totalClicks,
            startTime,
            nodesUnlockedCount: nodes.filter(n => n.purchased).length,
          },
        }}
        onResetGame={handleResetGame}
      />
    </div>
  );
}
