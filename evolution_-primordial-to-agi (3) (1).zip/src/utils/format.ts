const SUFFIXES = [
  '',
  'K',
  'M',
  'B',
  'T',
  'Qa',
  'Qi',
  'Sx',
  'Sp',
  'Oc',
  'No',
  'Dc',
  'Ud',
  'Dd',
  'Td',
  'Qad',
  'Qid',
  'Sxd',
  'Spd',
  'Ocd',
  'Nod',
  'Vg',
];

export function formatNumber(num: number): string {
  if (num === null || num === undefined || isNaN(num)) return '0';
  if (num < 0) return '-' + formatNumber(-num);
  if (num < 1000) {
    return num % 1 === 0 ? num.toString() : num.toFixed(1);
  }

  const exp = Math.floor(Math.log10(num) / 3);
  if (exp >= SUFFIXES.length) {
    return num.toExponential(2);
  }

  const scaled = num / Math.pow(10, exp * 3);
  return `${scaled.toFixed(scaled < 10 ? 2 : 1)} ${SUFFIXES[exp]}`;
}

export function formatPrecise(num: number): string {
  if (num < 10) return num.toFixed(2);
  if (num < 100) return num.toFixed(1);
  return formatNumber(num);
}

export function formatTime(seconds: number): string {
  if (seconds < 60) return `${Math.floor(seconds)}s`;
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  if (mins < 60) return `${mins}m ${secs}s`;
  const hours = Math.floor(mins / 60);
  const remMins = mins % 60;
  return `${hours}h ${remMins}m`;
}
