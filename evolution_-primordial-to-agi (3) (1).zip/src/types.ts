export type EraId = 
  | 'hadean'          // Molten Earth
  | 'primordial'      // Pre-biotic ocean & RNA
  | 'cambrian'        // Ocean life explosion
  | 'terrestrial'     // Land plants, reptiles & mammals
  | 'consciousness'   // Early hominids & tools
  | 'civilization'    // Agriculture, industry & electricity
  | 'digital'         // Silicon, computers & neural networks
  | 'agi_breaking';   // The Breaking of AGI & Post-Biological Singularity

export interface EraInfo {
  id: EraId;
  name: string;
  subtitle: string;
  description: string;
  requiredEntropy: number;
  color: string;
  glowColor: string;
  soundTrackTrack: string;
  eraMultiplier: number;        // Global production & click multiplier for unlocking this era
  instantRewardEntropy: number; // Massive instant bonus upon ascending to this epoch
  planetTheme: {
    atmosphereColor: string;
    oceanColor: string;
    landColor: string;
    cloudColor: string;
    hasCityLights: boolean;
    hasDataGrid: boolean;
    hasAgiRings: boolean;
    magmaCracks: boolean;
  };
}

export type NodeCategory = 'organic' | 'biological' | 'cognitive' | 'civilization' | 'digital' | 'singularity';

export interface TechNode {
  id: string;
  name: string;
  category: NodeCategory;
  era: EraId;
  description: string;
  scientificFact: string;
  entropyCost: number;
  ideasCost?: number;
  prerequisites: string[];
  unlocked: boolean;
  purchased: boolean;
  position: { x: number; y: number }; // Relative coordinates in tech tree canvas
  entropyMultiplier?: number;
  clickMultiplier?: number;
  ideasMultiplier?: number;
  specialEffect?: string;
  iconName: string;
}

export interface Generator {
  id: string;
  name: string;
  category: 'biotic' | 'intelligence' | 'machinery';
  era: EraId;
  description: string;
  count: number;
  baseCost: number;
  currency: 'entropy' | 'ideas';
  baseProduction: number; // production per second
  productionType: 'entropy' | 'ideas';
  costMultiplier: number;
  iconName: string;
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
}

export interface GameState {
  entropy: number;
  totalEntropy: number;
  ideas: number;
  totalIdeas: number;
  entropyPerSecond: number;
  ideasPerSecond: number;
  clickPower: number;
  currentEra: EraId;
  unlockedEras: EraId[];
  realityFlux: number; // Prestige currency
  prestigeCount: number;
  agiBreakTriggered: boolean;
  soundtrackMuted: boolean;
  soundtrackVolume: number;
  soundEffectsVolume: number;
  stats: {
    totalClicks: number;
    startTime: number;
    nodesUnlockedCount: number;
    agiAchievedAt?: number;
  };
}
