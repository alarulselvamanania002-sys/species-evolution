/**
 * Atmospheric Sound Engine powered by Web Audio API
 * Generates continuous generative ambient space drones, era-specific musical chord progressions,
 * and harmonious interactive pentatonic tap notes.
 */

import { EraId } from '../types';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  
  // Ambient drone nodes
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private droneFilter: BiquadFilterNode | null = null;
  private lfoOsc: OscillatorNode | null = null;
  private lfoGain: GainNode | null = null;
  
  private isMuted: boolean = false;
  private musicVol: number = 0.45;
  private sfxVol: number = 0.5;
  private currentEra: EraId = 'hadean';
  private pentatonicIndex: number = 0;
  private chordIntervalId: number | null = null;

  // Pentatonic scales for tap notes (frequencies in Hz)
  private eraScales: Record<EraId, number[]> = {
    hadean: [110, 130.81, 146.83, 164.81, 196.00, 220.00], // A2 minor pentatonic (deep, volcanic)
    primordial: [146.83, 164.81, 196.00, 220.00, 261.63, 293.66], // D minor pentatonic (oceanic)
    cambrian: [174.61, 196.00, 220.00, 261.63, 293.66, 349.23], // F major pentatonic (organic bloom)
    terrestrial: [196.00, 220.00, 246.94, 293.66, 329.63, 392.00], // G major pentatonic (lush)
    consciousness: [220.00, 246.94, 277.18, 329.63, 369.99, 440.00], // A major (awakening)
    civilization: [261.63, 293.66, 329.63, 392.00, 440.00, 523.25], // C major (monumental)
    digital: [293.66, 329.63, 369.99, 440.00, 493.88, 587.33], // D major cyber (crisp)
    agi_breaking: [220.00, 277.18, 329.63, 415.30, 440.00, 554.37, 659.25], // Mystical cosmic Lydian / transcendent
  };

  private eraDroneFreqs: Record<EraId, [number, number, number]> = {
    hadean: [55, 110, 180], // Sub-bass, heavy rumble
    primordial: [65.41, 130.81, 260], // Deep oceanic C
    cambrian: [73.42, 146.83, 340], // D vitality
    terrestrial: [82.41, 164.81, 400], // E lush earth
    consciousness: [98.00, 196.00, 520], // G conscious pulse
    civilization: [110.00, 220.00, 650], // A civilization harmony
    digital: [146.83, 293.66, 880], // High-tech silicon resonance
    agi_breaking: [110.00, 329.63, 1200], // AGI cosmic transcendence
  };

  public init() {
    if (this.ctx) return;
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(1.0, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(this.musicVol, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(this.sfxVol, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);

      this.startAmbientSoundtrack();
    } catch {
      console.warn('Web Audio API not supported or user gesture required');
    }
  }

  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private startAmbientSoundtrack() {
    if (!this.ctx || !this.musicGain) return;

    // Filtered multi-oscillator drone with slow breathing LFO
    const [f1, f2, cutoff] = this.eraDroneFreqs[this.currentEra];

    this.droneFilter = this.ctx.createBiquadFilter();
    this.droneFilter.type = 'lowpass';
    this.droneFilter.frequency.setValueAtTime(cutoff, this.ctx.currentTime);
    this.droneFilter.Q.setValueAtTime(3.0, this.ctx.currentTime);
    this.droneFilter.connect(this.musicGain);

    this.droneOsc1 = this.ctx.createOscillator();
    this.droneOsc1.type = 'sine';
    this.droneOsc1.frequency.setValueAtTime(f1, this.ctx.currentTime);

    this.droneOsc2 = this.ctx.createOscillator();
    this.droneOsc2.type = 'triangle';
    this.droneOsc2.frequency.setValueAtTime(f2 * 1.002, this.ctx.currentTime); // Slight beating detune

    // LFO for atmospheric breathing swell
    this.lfoOsc = this.ctx.createOscillator();
    this.lfoOsc.type = 'sine';
    this.lfoOsc.frequency.setValueAtTime(0.08, this.ctx.currentTime); // 12-second slow breath

    this.lfoGain = this.ctx.createGain();
    this.lfoGain.gain.setValueAtTime(cutoff * 0.4, this.ctx.currentTime);

    this.lfoOsc.connect(this.lfoGain);
    this.lfoGain.connect(this.droneFilter.frequency);

    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.28, this.ctx.currentTime);
    this.droneOsc1.connect(subGain);
    this.droneOsc2.connect(subGain);
    subGain.connect(this.droneFilter);

    this.droneOsc1.start();
    this.droneOsc2.start();
    this.lfoOsc.start();

    // Start recurring procedural pad chord progression
    this.startAtmosphericChords();
  }

  private startAtmosphericChords() {
    if (this.chordIntervalId) clearInterval(this.chordIntervalId);
    
    // Play a gentle ambient chord every 12 seconds
    this.chordIntervalId = window.setInterval(() => {
      this.triggerAmbientChime();
    }, 12000);
  }

  private triggerAmbientChime() {
    if (!this.ctx || !this.musicGain || this.isMuted) return;
    const now = this.ctx.currentTime;
    const scale = this.eraScales[this.currentEra];
    
    // Pick 2 harmonious notes
    const note1 = scale[0] * 2;
    const note2 = scale[Math.floor(Math.random() * (scale.length - 1)) + 1] * 2;

    [note1, note2].forEach((freq, idx) => {
      if (!this.ctx || !this.musicGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(900, now);

      osc.type = this.currentEra === 'digital' || this.currentEra === 'agi_breaking' ? 'sawtooth' : 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.3);

      gain.gain.setValueAtTime(0, now + idx * 0.3);
      gain.gain.linearRampToValueAtTime(0.06, now + idx * 0.3 + 1.2);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.3 + 6.0);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.musicGain);

      osc.start(now + idx * 0.3);
      osc.stop(now + idx * 0.3 + 6.1);
    });
  }

  public setEra(era: EraId) {
    this.currentEra = era;
    if (!this.ctx || !this.droneOsc1 || !this.droneOsc2 || !this.droneFilter) return;

    const [f1, f2, cutoff] = this.eraDroneFreqs[era];
    const now = this.ctx.currentTime;

    // Smoothly glide to the new planetary frequency
    this.droneOsc1.frequency.linearRampToValueAtTime(f1, now + 3);
    this.droneOsc2.frequency.linearRampToValueAtTime(f2 * 1.002, now + 3);
    this.droneFilter.frequency.linearRampToValueAtTime(cutoff, now + 3);

    // Play milestone ascension chord
    this.playMilestoneChime();
  }

  public playTapNote() {
    this.init();
    this.resume();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const scale = this.eraScales[this.currentEra];
    const freq = scale[this.pentatonicIndex % scale.length];
    this.pentatonicIndex++;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    // Sound character shifts with era
    if (this.currentEra === 'hadean' || this.currentEra === 'primordial') {
      osc.type = 'triangle';
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(600, now);
    } else if (this.currentEra === 'digital' || this.currentEra === 'agi_breaking') {
      osc.type = 'square';
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(freq * 1.8, now);
      filter.Q.setValueAtTime(4.0, now);
    } else {
      osc.type = 'sine';
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1400, now);
    }

    osc.frequency.setValueAtTime(freq * 2, now);

    // Dynamic pluck envelope
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(0.2, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.55);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.6);
  }

  public playUnlockSound() {
    this.init();
    this.resume();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const notes = [261.63, 329.63, 392.00, 523.25]; // C major arpeggio

    notes.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.07);

      gain.gain.setValueAtTime(0.001, now + i * 0.07);
      gain.gain.linearRampToValueAtTime(0.18, now + i * 0.07 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.07 + 0.45);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + i * 0.07);
      osc.stop(now + i * 0.07 + 0.5);
    });
  }

  public playMilestoneChime() {
    this.init();
    this.resume();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    // Majestic ethereal chord
    const chord = [220, 329.63, 440, 554.37, 659.25];

    chord.forEach((freq) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.15, now + 0.4);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.5);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now);
      osc.stop(now + 3.6);
    });
  }

  public playAgiBreakdownSiren() {
    this.init();
    this.resume();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    // Reality warp sound: sweeping frequencies, cosmic white noise burst
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(1800, now + 2.5);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.3, now + 0.5);
    gain.gain.linearRampToValueAtTime(0.35, now + 2.0);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 4.0);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 4.1);
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 1.0, this.ctx.currentTime);
    }
    return this.isMuted;
  }

  public setMusicVolume(val: number) {
    this.musicVol = val;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setValueAtTime(val, this.ctx.currentTime);
    }
  }

  public setSfxVolume(val: number) {
    this.sfxVol = val;
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setValueAtTime(val, this.ctx.currentTime);
    }
  }

  public getStatus() {
    return {
      isMuted: this.isMuted,
      musicVolume: this.musicVol,
      sfxVolume: this.sfxVol,
      isInitialized: this.ctx !== null,
    };
  }
}

export const soundEngine = new SoundEngine();
